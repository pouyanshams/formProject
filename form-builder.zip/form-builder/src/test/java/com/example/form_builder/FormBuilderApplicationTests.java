package com.example.form_builder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
